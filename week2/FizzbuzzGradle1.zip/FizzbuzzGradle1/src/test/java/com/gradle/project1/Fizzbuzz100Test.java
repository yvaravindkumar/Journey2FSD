package com.gradle.project1;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class Fizzbuzz100Test {

    Fizzbuzz100 fb = new Fizzbuzz100();
    @Test
    public void FizzbuzzNormalNumbers() {

//        Fizzbuzz100 fb = new Fizzbuzz100();
        Assertions.assertEquals("1", fb.convert(1));
        Assertions.assertEquals("2", fb.convert(2));
    }

    @Test
    public void FizzbuzzThreeNumbers(){
//        Fizzbuzz100 fb = new Fizzbuzz100();
        Assertions.assertEquals("Fizz",fb.convert(21));
        Assertions.assertEquals("Fizz",fb.convert(33));
    }

    @Test
    public void FizzbuzzFiveNumbers(){
//        Fizzbuzz100 fb = new Fizzbuzz100();
        Assertions.assertEquals("Buzz",fb.convert(55));
        Assertions.assertEquals("Buzz",fb.convert(25));
    }

    @Test
    public void FizzbuzzFifteenNumbers(){
        Assertions.assertEquals("Fizzbuzz",fb.convert(15));
        Assertions.assertEquals("Fizzbuzz",fb.convert(75));
    }
}