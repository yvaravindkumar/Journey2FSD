package com.gradle.project1;

public class Fizzbuzz100 {
    public static void main(String[] args){
        for(int i=1;i<=100;i++){
            System.out.println(convert(i));
        }
    }

    public static String convert(Integer i){

        if(i%15==0){
            return "Fizzbuzz";
        }
        else if(i%3==0){
            return "Fizz";
        }
        else if(i%5==0){
            return "Buzz";
        }
        return String.valueOf(i);
    }

}
